package com.example.emergency

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
