# emergency_operations_system
## using Flutter , Dart and FireBase
1- Helping doctors and nurses know the status of all operating rooms (if they need sterilization, are occupied, or
ready) to help the staff know and determine whether the patient will have this operation in the hospital or will be
transferred to another hospital to provide quick answers in cases emergency services without tampering with the
patient's life and saving time to save his life, and also assisting the nurse in knowing which operating room needs
sterilization and changing its condition after sterilization to ready or during use to busy.
2- Determining permissions for each user, so the store administrator cannot enter the nursing page or anything like
that, and only the admin has all the permission and he is the only one who has the right to register a new user in the
program
3- Building a system for the pharmacy to monitor consumption and alert when the quantity of any treatment runs
out, submit reports for consumption and assist them in the inventory process, instead of being manual, it became
automatic.
4- Building a system for storing medical supplies similar to the pharmacy system
5- Assisting the nursing in recording the medical supplies and medicines consumed during each operation for each
patient and presenting them to the admin.

emergency3 in this path "D:\myWork\3rd year\smester 2\practical\emergency implementation3"